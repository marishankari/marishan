package com.example.administrator.inventory;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class PersonListAdapter extends ArrayAdapter<Person>{

    public static final String TAG="PersonListAdapter";
    private Context mContext;
    int mResource;

    public PersonListAdapter(@NonNull Context context, int resource, ArrayList<Person> objects) {
        super(context, resource, objects);
        mContext = context;
        mResource = resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {


        String time=getItem(position).getTime();
        String inv=getItem(position).getInv();
        String quality=getItem(position).getQuality();
        String dummy=getItem(position).getDummy();

        Person person= new Person(time,inv,quality,dummy);
        LayoutInflater inflater= LayoutInflater.from(mContext);
        convertView = inflater.inflate(mResource, parent, false);

        TextView tvTime = (TextView)convertView.findViewById(R.id.textTim);
        TextView tvInv = (TextView)convertView.findViewById(R.id.textInv);
        TextView tvQua = (TextView)convertView.findViewById(R.id.textQua);
        TextView tvDummy = (TextView)convertView.findViewById(R.id.textDummy);

        tvTime.setText(time);
        tvInv.setText(inv);
        tvQua.setText(quality);
        tvDummy.setText(dummy);

        return convertView;


    }
}
