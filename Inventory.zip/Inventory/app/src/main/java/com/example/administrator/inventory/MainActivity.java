package com.example.administrator.inventory;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public Button btnLogin;
    public static EditText userNam;
    public String text1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnLogin=(Button)findViewById(R.id.btnName);
        userNam=(EditText)findViewById(R.id.userName);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(userNam.length() > 0){
                    Intent add=new Intent(getApplicationContext(),InventoryAdd.class);
                    startActivity(add);
                }
                else
                {
                    Context context=getApplicationContext();
                    CharSequence text="Must Enter Username before you can proceed";
                    int duration=Toast.LENGTH_SHORT;
                    Toast toast=Toast.makeText(context,text,duration);
                    toast.show();
                }
            }
        });

    }
    public static void homefin(){
        int pid = android.os.Process.myPid();
        android.os.Process.killProcess(pid);

    }
}
