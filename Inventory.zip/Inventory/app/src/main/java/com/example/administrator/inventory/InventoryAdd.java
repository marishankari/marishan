package com.example.administrator.inventory;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class InventoryAdd extends AppCompatActivity implements AdapterView.OnItemSelectedListener{

    Spinner spinner;
    Button showItem;
    Button addItem;
    EditText Invoiceno;
    public static ArrayList<String> addedinvno = new ArrayList<String>();
    public static ArrayList<String> addedquality = new ArrayList<String>();
    public static ArrayList<String> addedtime = new ArrayList<String>();
    public static ArrayList<String> addedname = new ArrayList<String>();
    public static ArrayList<Person> added = new ArrayList<>();
    int size = addedtime.size();
    String six= String.valueOf(size);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_add);

        spinner = (Spinner) findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.spinner_item,android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);
        Invoiceno=(EditText)findViewById(R.id.Invoiceno);


        showItem=(Button) findViewById(R.id.btnShowitems);
        showItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showItemto();
            }
        });

        addItem=(Button) findViewById(R.id.Additems);

        addItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String textspin=spinner.getSelectedItem().toString();
                String texttoast="Entry not saved as not all data entered. \n Complete all entries and try again";
                if(textspin.length() < 1) {

                    Toast.makeText(getApplicationContext(), texttoast, Toast.LENGTH_SHORT).show();

                }
                else if(Invoiceno.length() < 1){

                    Toast.makeText(getApplicationContext(), texttoast, Toast.LENGTH_SHORT).show();
                }
                else{
                    String invtoit=Invoiceno.getEditableText().toString();
                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
                    String cdt = sdf.format(new Date());
                    addItemready(invtoit,textspin,cdt);
                }
            }
        });

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        //String text=parent.getItemAtPosition(position).toString();
        //Toast.makeText(parent.getContext(),text,Toast.LENGTH_SHORT).show();

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
    public  void addItemready(String inv,String ite,String cdt){

        addedinvno.add(inv);
        addedquality.add(ite);
        addedtime.add(cdt);
        String dummy=MainActivity.userNam.getText().toString();
        addedname.add(dummy);
        Person add = new Person(cdt,inv,ite,dummy);

        added.add(add);

            Toast.makeText(getApplicationContext(), "Data Added", Toast.LENGTH_SHORT).show();



    }

    public void showItemto(){

        Intent showi=new Intent(getApplicationContext(),InventoyShow.class);
        startActivity(showi);
        //Toast.makeText(getApplicationContext(), "Work in progress", Toast.LENGTH_SHORT).show();

    }


}
