package com.example.administrator.inventory;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class InventoyShow extends AppCompatActivity {

    private static final String TAG = "InventoryShow";
    public Button profile;
    public Button back;
    DatabaseHelper myDB;
    ArrayList<String> nam=new ArrayList<String>();
    ArrayList<String> invn=new ArrayList<String>();
    ArrayList<String> tim=new ArrayList<String>();
    ArrayList<String> qua=new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventoy_show);

        Log.d(TAG,"oncreate: Started.");
        ListView mListView=(ListView)findViewById(R.id.listview);

        PersonListAdapter adapter=new PersonListAdapter(this,R.layout.adapter_view_layout,InventoryAdd.added);
        mListView.setAdapter(adapter);
        back=(Button)findViewById(R.id.backin);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent add=new Intent(getApplicationContext(),InventoryAdd.class);
                startActivity(add);

            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
       getMenuInflater().inflate(R.menu.mymenu,menu);
       return true;

    }

    public boolean onOptionsItemSelected(MenuItem item){
        super.onOptionsItemSelected(item);
        switch (item.getItemId()){

            case R.id.profile:
                profileopen();
                break;
            case R.id.send:
                sendopen();
                break;
            case R.id.save:
                saveopen();
                break;
              default:
                  break;


        }
        return true;
    }
    public void profileopen(){

        Intent add=new Intent(getApplicationContext(),InventoryProfile.class);
        startActivity(add);
    }
    public void saveopen(){
        String mine;
        int i;
        nam=InventoryAdd.addedname;
        invn=InventoryAdd.addedinvno;
        qua=InventoryAdd.addedquality;
        tim=InventoryAdd.addedtime;
        int data=nam.size();

        //Toast.makeText(getApplicationContext(),"Working", Toast.LENGTH_SHORT).show();

        for( i=0; i <= data; i++ ){


           //AddData(tim.get(i).toString(),invn.get(i).toString(),qua.get(i),nam.get(i).toString());

        }
        Toast.makeText(getApplicationContext(), "Data saved to DB", Toast.LENGTH_SHORT).show();



    }
    public void sendopen(){

        final AlertDialog.Builder builder=new AlertDialog.Builder(InventoyShow.this);
        builder.setMessage("Are you Sure? This will delete all Entries");
        builder.setCancelable(true);
        builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                InventoryAdd.added.clear();
                Toast.makeText(getApplicationContext(), "All Datas Cleared", Toast.LENGTH_SHORT).show();
                finish();
                startActivity(getIntent());
            }
        });
        AlertDialog alertDialog=builder.create();
        alertDialog.show();

    }

    @Override
    public void onBackPressed() {

        final AlertDialog.Builder builder=new AlertDialog.Builder(InventoyShow.this);
        builder.setMessage("Save Entries to DB first ? ");
        builder.setCancelable(true);
        builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //Intent intent = new Intent(Intent.ACTION_MAIN);
                //intent.addCategory(Intent.CATEGORY_HOME);
                //startActivity(intent);
                //int pid = android.os.Process.myPid();
                //android.os.Process.killProcess(pid);
                //finish();
                //MainActivity.homefin();
                InventoryAdd.added.clear();
                finish();
                Intent add=new Intent(getApplicationContext(),MainActivity.class);
                startActivity(add);
                Intent intent = new Intent(Intent.ACTION_MAIN);
                intent.addCategory(Intent.CATEGORY_HOME);
                startActivity(intent);

            }
        });
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getApplicationContext(), "Data saved to DB", Toast.LENGTH_SHORT).show();
                finish();
                Intent add=new Intent(getApplicationContext(),MainActivity.class);
                startActivity(add);
                Intent intent = new Intent(Intent.ACTION_MAIN);
                intent.addCategory(Intent.CATEGORY_HOME);
                startActivity(intent);

            }
        });
        AlertDialog alertDialog=builder.create();
        alertDialog.show();

    }

    public void AddData(String time,String invno,String quality,String dummy){

        //boolean insertdata= myDB.addData(time, invno, quality, dummy);
    }


}
