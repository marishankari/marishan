package com.example.administrator.inventory;

public class Person {
    private String dummy;
    private String time;
    private String inv;
    private String quality;

    public Person(String time, String inv, String quality,String dummy) {
        this.dummy = dummy;
        this.time = time;
        this.inv = inv;
        this.quality = quality;
    }

    public String getDummy() {
        return dummy;
    }

    public void setDummy(String dummy) {
        this.dummy = dummy;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getInv() {
        return inv;
    }

    public void setInv(String inv) {
        this.inv = inv;
    }

    public String getQuality() {
        return quality;
    }

    public void setQuality(String quality) {
        this.quality = quality;
    }
}



