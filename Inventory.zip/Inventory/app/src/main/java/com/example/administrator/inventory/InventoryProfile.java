package com.example.administrator.inventory;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class InventoryProfile extends AppCompatActivity {


    Button save;
    Button cancel;
    EditText newusername;
    EditText newpassword;
    EditText newrepeatpassword;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_profile);
        save=(Button)findViewById(R.id.buttonPsave);
        cancel=(Button)findViewById(R.id.buttonPcancel);
        newusername=(EditText)findViewById(R.id.nuser);
        newpassword=(EditText)findViewById(R.id.npass);
        newrepeatpassword=(EditText)findViewById(R.id.nrpass);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent add=new Intent(getApplicationContext(),MainActivity.class);
                startActivity(add);
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent add=new Intent(getApplicationContext(),MainActivity.class);
                startActivity(add);
            }
        });


    }
}
